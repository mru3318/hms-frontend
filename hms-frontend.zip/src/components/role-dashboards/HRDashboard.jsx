import React from "react";

const HRDashboard = () => {
  return (
    <div className="p-4">
      <h2>HR Dashboard</h2>
      <p>Employee management, attendance and payroll overview.</p>
    </div>
  );
};

export default HRDashboard;
