import React, { useState } from "react";

export default function Radiology() {
  const SCAN_CATALOG = {
    "Chest X-Ray": { cost: 500 },
    "Abdominal Ultrasound": { cost: 1200 },
    "Brain MRI": { cost: 3500 },
    "CT Abdomen": { cost: 3000 },
    "KUB Ultrasound": { cost: 1000 },
    "Cervical Spine X-Ray": { cost: 600 },
    "Pelvis X-Ray": { cost: 700 },
  };

  const [form, setForm] = useState({
    patientName: "",
    age: "",
    gender: "",
    contact: "",
    patientId: "",
    doctor: "",
    email: "",
  });

  const [scans, setScans] = useState([
    { name: "", findings: "", impression: "", cost: 0 },
  ]);

  const [remarks, setRemarks] = useState("");

  const updateField = (key, value) => {
    setForm({ ...form, [key]: value });
  };

  const addScan = () => {
    setScans([...scans, { name: "", findings: "", impression: "", cost: 0 }]);
  };

  const removeScan = (index) => {
    const temp = [...scans];
    temp.splice(index, 1);
    setScans(
      temp.length ? temp : [{ name: "", findings: "", impression: "", cost: 0 }]
    );
  };

  const updateScan = (index, key, value) => {
    const temp = [...scans];
    temp[index][key] = value;

    if (key === "name") {
      const selected = SCAN_CATALOG[value];
      temp[index].cost = selected ? selected.cost : 0;
    }

    setScans(temp);
  };

  const scanCount = scans.length;
  const totalAmount = scans.reduce((sum, s) => sum + Number(s.cost || 0), 0);

  const validateAll = () => {
    return (
      form.patientName &&
      form.age &&
      form.gender &&
      form.contact &&
      form.patientId
    );
  };

  const handlePrint = () => {
    if (validateAll()) window.print();
    else alert("Please fill all required fields!");
  };

  const handleSave = () => {
    if (validateAll()) alert("Radiology report saved successfully!");
    else alert("Please fill all required fields!");
  };

  return (
    <div className="container my-4 bg-light">
      {/* HEADER */}
      <div
        className="text-white p-4 rounded mb-4 shadow-sm"
        style={{ background: "#01c0c8" }}
      >
        <h3 className="mb-0">
          <i className="fas fa-x-ray me-2"></i> Radiology - Form
        </h3>
      </div>

      {/* PATIENT INFORMATION */}
      <div className="card mb-4 shadow-sm">
        <div
          className="card-header text-white fw-bold"
          style={{ background: "#01c0c8" }}
        >
          Patient Information
        </div>

        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-4">
              <label className="form-label">Patient Name *</label>
              <input
                type="text"
                className="form-control"
                value={form.patientName}
                onChange={(e) => updateField("patientName", e.target.value)}
              />
            </div>

            <div className="col-md-2">
              <label className="form-label">Age *</label>
              <input
                type="number"
                className="form-control"
                value={form.age}
                onChange={(e) => updateField("age", e.target.value)}
              />
            </div>

            <div className="col-md-2">
              <label className="form-label">Gender *</label>
              <select
                className="form-select"
                value={form.gender}
                onChange={(e) => updateField("gender", e.target.value)}
              >
                <option value="">Select</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
              </select>
            </div>

            <div className="col-md-4">
              <label className="form-label">Contact Number *</label>
              <input
                type="number"
                className="form-control"
                value={form.contact}
                onChange={(e) => updateField("contact", e.target.value)}
              />
            </div>

            <div className="col-md-3">
              <label className="form-label">Patient ID (MRN) *</label>
              <input
                type="text"
                className="form-control"
                value={form.patientId}
                onChange={(e) => updateField("patientId", e.target.value)}
              />
            </div>

            <div className="col-md-5">
              <label className="form-label">Referring Doctor</label>
              <input
                type="text"
                className="form-control"
                value={form.doctor}
                onChange={(e) => updateField("doctor", e.target.value)}
              />
            </div>

            <div className="col-md-4">
              <label className="form-label">Email (optional)</label>
              <input
                type="email"
                className="form-control"
                value={form.email}
                onChange={(e) => updateField("email", e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* RADIOLOGY SCAN + BILLING */}
      <div className="row">
        {/* Scan Section */}
        <div className="col-md-6 mb-4">
          <div className="card shadow-sm h-100">
            <div
              className="card-header text-white fw-bold"
              style={{ background: "#01c0c8" }}
            >
              Radiology Scan Details
            </div>
            <div className="card-body">
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Scan Type</label>
                  <select className="form-select">
                    <option>X-Ray</option>
                    <option>CT Scan</option>
                    <option>MRI</option>
                    <option>Ultrasound</option>
                    <option>Mammography</option>
                    <option>Others</option>
                  </select>
                </div>

                <div className="col-md-6">
                  <label className="form-label">Scan Date</label>
                  <input type="date" className="form-control" />
                </div>

                <div className="col-md-6">
                  <label className="form-label">Scan Time</label>
                  <input type="time" className="form-control" />
                </div>

                <div className="col-md-6">
                  <label className="form-label">Performed By</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Technician"
                  />
                </div>

                <div className="col-md-12">
                  <label className="form-label">Upload Report File</label>
                  <input type="file" className="form-control" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Billing */}
        <div className="col-md-6 mb-4">
          <div className="card shadow-sm h-100">
            <div
              className="card-header text-white fw-bold"
              style={{ background: "#01c0c8" }}
            >
              Billing Summary
            </div>
            <div className="card-body text-center">
              <div className="d-flex justify-content-around">
                <div>
                  <div className="fw-bold">Scans Count</div>
                  <h4 className="text-primary">{scanCount}</h4>
                </div>
                <div>
                  <div className="fw-bold">Total (₹)</div>
                  <h4 className="text-success">{totalAmount.toFixed(2)}</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SCAN TABLE */}
      <div className="card mb-4 shadow-sm">
        <div
          className="card-header text-white fw-bold"
          style={{ background: "#01c0c8" }}
        >
          Radiology Report Entries
        </div>

        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-bordered align-middle text-center">
              <thead className="table-info">
                <tr>
                  <th>Scan Name</th>
                  <th>Findings</th>
                  <th>Impression</th>
                  <th>Cost (₹)</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {scans.map((s, i) => (
                  <tr key={i}>
                    <td>
                      <input
                        list="scanList"
                        className="form-control"
                        value={s.name}
                        onChange={(e) => updateScan(i, "name", e.target.value)}
                      />
                    </td>

                    <td>
                      <textarea
                        className="form-control"
                        value={s.findings}
                        onChange={(e) =>
                          updateScan(i, "findings", e.target.value)
                        }
                      />
                    </td>

                    <td>
                      <textarea
                        className="form-control"
                        value={s.impression}
                        onChange={(e) =>
                          updateScan(i, "impression", e.target.value)
                        }
                      />
                    </td>

                    <td>
                      <input
                        type="number"
                        className="form-control"
                        value={s.cost}
                        onChange={(e) => updateScan(i, "cost", e.target.value)}
                      />
                    </td>

                    <td>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => removeScan(i)}
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button
            className="btn btn-outline-primary btn-sm me-2"
            onClick={addScan}
          >
            + Add Scan
          </button>

          <button
            className="btn btn-outline-secondary btn-sm"
            onClick={() =>
              setScans([{ name: "", findings: "", impression: "", cost: 0 }])
            }
          >
            Clear All
          </button>
        </div>
      </div>

      {/* REMARKS */}
      <div className="card mb-4 shadow-sm">
        <div
          className="card-header text-white fw-bold"
          style={{ background: "#01c0c8" }}
        >
          Radiologist Remarks / Summary
        </div>

        <div className="card-body">
          <textarea
            className="form-control"
            rows="4"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
          ></textarea>
        </div>
      </div>

      {/* BUTTONS */}
      <div className="text-center mb-4">
        <button className="btn btn-success me-2" onClick={handleSave}>
          💾 Save
        </button>
        <button className="btn btn-primary" onClick={handlePrint}>
          🖨 Print
        </button>
      </div>

      {/* DATALIST */}
      <datalist id="scanList">
        {Object.keys(SCAN_CATALOG).map((s, i) => (
          <option key={i} value={s}></option>
        ))}
      </datalist>
    </div>
  );
}
