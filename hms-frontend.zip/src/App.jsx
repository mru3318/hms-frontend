import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./layout/Layout";
import AddDoctor from "./components/add-doctor/AddDoctor";
import AdminDashboard from "./components/admin-dashboard/AdminDashboard";
import { RoleProvider } from "./role/RoleContext";
import DashboardWrapper from "./components/role-dashboards/DashboardWrapper";
import ManageEmployee from "./components/human-resorces/manage-employee/ManageEmployee";
import AmbulanceAdd from "./components/ambulance/ambulance-add/AmbulanceAdd";
import AmbulanceAssignment from "./components/ambulance/ambulance-assignment/AmbulanceAssignment";
import AmbulanceDashboard from "./components/ambulance/ambulance-dashboard/AmbulanceDashboard";
import AddDriver from "./components/ambulance/add-driver/AddDriver";
import BedList from "./components/bed-manager/bed-list/BedList";
import BedAssign from "./components/bed-manager/bed-assign/BedAssign";
import AllottedBeds from "./components/bed-manager/alloted-beds/AllottedBeds";
import AddBeds from "./components/bed-manager/add-beds/AddBeds";
import AddRoom from "./components/bed-manager/add-room/AddRoom";
import LoginPage from "./components/auth/login/LoginPage";
import ForgotPassword from "./components/auth/forgot-password/ForgotPassword";
import ViewNotices from "./components/notice/manage-notice/view-notice/ViewNotices";
import CreateNotice from "./components/notice/manage-notice/add-new-notice/CreateNotice";
import EmployeeRegistration from "./components/human-resorces/add-new-employee/EmployeeRegistration";
import ManageDepartment from "./components/department/ManageDepartment";
import UpdateDepartment from "./components/department/UpdateDepartment";
import AddDepartment from "./components/department/AddDepartment";
import AddAsset from "./components/asset-management/add-asset/AddAsset";
import AssetList from "./components/asset-management/asset-list/AssetList";
import AddHealthPackage from "./components/helth-package/add-helth-package/AddHealthPackage";
import HealthPackages from "./components/helth-package/manage-helth-package/HealthPackages";
import UpdateHelthPackage from "./components/helth-package/update-package/UpdateHelthPackage";
import UpdateAsset from "./components/asset-management/update-asset/UpdateAsset";
import AddNewDonor from "./components/blood-bank/add-new-donor/AddNewDonor";
import ManageDonor from "./components/blood-bank/manage-donor/ManageDonor";
import AddBloodStock from "./components/blood-bank/add-stock/AddBloodStock";
import BloodStock from "./components/blood-bank/blood-stock/BloodStock";
import AddDonor from "./components/blood-bank/add-donor/AddDonor";
import BabyBirthCertificate from "./components/reports/baby-birth-certificate/BabyBirthCertificate";
import DeathCertificateForm from "./components/reports/deth-certificate/DeathCertificateForm";
import ManageBirthCertificates from "./components/reports/manage-birth-certificates/ManageBirthCertificates";
import EditBirthCertificate from "./components/reports/edit-birth-certificate/EditBirthCertificate";
import AddDoctorSchedule from "./components/doctor-schedule/add-schedule/AddDoctorSchedule";
import ManageDethCertificates from "./components/reports/manage-deth-certificates/ManageDethCertificates";
import EditDeathCertificateForm from "./components/reports/edit-death-certificate/EditDeathCertificateForm";
import PharmacyModule from "./components/pharmacy/PharmacyModule";
import DoctorScheduleList from "./components/doctor-schedule/schedule-list/DoctorScheduleList";
import EditDoctorSchedule from "./components/doctor-schedule/edit-doctor-schedule/EditDoctorSchedule";
import AddPathalogyForm from "./components/reports/pathalogy/add-pathalogy-report/AddPathalogyForm";
import RadiologyForm from "./components/reports/radiology/RadiologyForm";
import AddPatientAppointment from "./components/appointments/add-appointments/AddPatientAppointment";
import ViewPatientAppointment from "./components/appointments/view-appointments/ViewPatientAppointment";
import AddNewPrescription from "./components/prescriptions/add-new-prescription/AddNewPriscription";
import ManagePrescription from "./components/prescriptions/manage-priscription/ManagePrescription";
import PathologyReportList from "./components/reports/pathalogy/manage-pathalogy-report/PathologyReportList";
import RadiologyReportList from "./components/reports/radiology/manage-radiology-report/RadiologyReportList";
import EditNotice from "./components/notice/manage-notice/edit-notice/EditNotice";
import Settings from "./components/setting/Settings";
import EditPatientAppointment from "./components/appointments/edit-appointments/EditPatientAppointment";
import ProtectedRoute from "./components/auth/ProtectedRoute";

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <LoginPage />,
    },
    {
      path: "forgot-password",
      element: <ForgotPassword />,
    },
    {
      path: "registration",
      element: (
        <ProtectedRoute>
          <EmployeeRegistration />
        </ProtectedRoute>
      ),
    },
    {
      path: "dashboard",
      element: (
        <ProtectedRoute>
          <Layout />
        </ProtectedRoute>
      ),
      children: [
        {
          index: true,
          element: <DashboardWrapper />,
        },
        {
          path: "add-doctor",
          element: <AddDoctor />,
        },
        {
          path: "add-new-employee",
          element: <EmployeeRegistration />,
        },

        {
          path: "manage-employees",
          element: <ManageEmployee />,
        },

        // Ambulance Routes
        {
          path: "ambulance-add",
          element: <AmbulanceAdd />,
        },
        {
          path: "ambulance-assignment",
          element: <AmbulanceAssignment />,
        },
        {
          path: "ambulance-dashboard",
          element: <AmbulanceDashboard />,
        },
        {
          path: "add-driver",
          element: <AddDriver />,
        },

        // Bed Manager Routes
        {
          path: "bed-list",
          element: <BedList />,
        },
        {
          path: "bed-assign/:id",
          element: <BedAssign />,
        },
        {
          path: "allotted-beds",
          element: <AllottedBeds />,
        },
        {
          path: "add-beds",
          element: <AddBeds />,
        },
        {
          path: "add-room",
          element: <AddRoom />,
        },

        // Notice Management Routes
        {
          path: "manage-notices",
          element: <ViewNotices />,
        },
        {
          path: "add-new-notice",
          element: <CreateNotice />,
        },
        {
          path: "edit-notice/:id",
          element: <EditNotice />,
        },

        //Department Routes
        {
          path: "manage-department",
          element: <ManageDepartment />,
        },
        {
          path: "update-department/:id",
          element: <UpdateDepartment />,
        },
        {
          path: "add-department",
          element: <AddDepartment />,
        },

        // Asset Management Routes
        {
          path: "add-asset",
          element: <AddAsset />,
        },
        {
          path: "asset-list",
          element: <AssetList />,
        },
        {
          path: "update-asset/:id",
          element: <UpdateAsset />,
        },

        //Helth Package Routes
        {
          path: "add-health-package",
          element: <AddHealthPackage />,
        },
        {
          path: "manage-health-packages",
          element: <HealthPackages />,
        },
        {
          path: "update-health-package/:id",
          element: <UpdateHelthPackage />,
        },

        // Donor Management Routes
        {
          path: "add-new-donor",
          element: <AddNewDonor />,
        },
        {
          path: "manage-donors",
          element: <ManageDonor />,
        },
        {
          path: "add-stock",
          element: <AddBloodStock />,
        },
        {
          path: "blood-stock",
          element: <BloodStock />,
        },
        {
          path: "add-donor",
          element: <AddDonor />,
        },

        //reports routes here
        {
          path: "baby-birth-certificate",
          element: <BabyBirthCertificate />,
        },
        {
          path: "death-certificate",
          element: <DeathCertificateForm />,
        },
        {
          path: "manage-birth-certificates",
          element: <ManageBirthCertificates />,
        },
        {
          path: "edit-birth-certificate/:id",
          element: <EditBirthCertificate />,
        },
        {
          path: "manage-death-certificates",
          element: <ManageDethCertificates />,
        },
        {
          path: "edit-death-certificate/:id",
          element: <EditDeathCertificateForm />,
        },
        {
          path: "add-radiology-report",
          element: <RadiologyForm />,
        },
        {
          path: "add-pathology-report",
          element: <AddPathalogyForm />,
        },
        {
          path: "manage-pathology-reports",
          element: <PathologyReportList />,
        },
        {
          path: "manage-radiology-reports",
          element: <RadiologyReportList />,
        },

        // Add Doctors Schedule
        {
          path: "add-doctor-schedule",
          element: <AddDoctorSchedule />,
        },

        {
          path: "view-doctor-schedule-list",
          element: <DoctorScheduleList />,
        },
        {
          path: "edit-doctor-schedule/:id",
          element: <EditDoctorSchedule />,
        },

        // Pharmacy Management Routes
        {
          path: "pharmacy-module",
          element: <PharmacyModule />,
        },

        // Appointments Management Routes
        {
          path: "add-patient-appointment",
          element: <AddPatientAppointment />,
        },
        {
          path: "view-patient-appointments",
          element: <ViewPatientAppointment />,
        },
        {
          path: "edit-patient-appointment/:id",
          element: <EditPatientAppointment />,
        },

        // Prescription Management Routes
        {
          path: "add-new-prescription",
          element: <AddNewPrescription />,
        },
        {
          path: "manage-prescriptions",
          element: <ManagePrescription />,
        },
        {
          path: "settings",
          element: <Settings />,
        },
      ],
    },
  ]);
  return (
    <RoleProvider>
      <RouterProvider router={router} />
    </RoleProvider>
  );
}

export default App;
