import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { API_BASE_URL } from "../../config";

// Decode JWT without external dependencies
function decodeBase64Url(input) {
  try {
    let base64 = input.replace(/-/g, "+").replace(/_/g, "/");
    const pad = base64.length % 4;
    if (pad) base64 += "=".repeat(4 - pad);
    const atobFn =
      typeof atob === "function"
        ? atob
        : typeof window !== "undefined" && typeof window.atob === "function"
        ? window.atob
        : null;
    if (!atobFn) return null;
    return decodeURIComponent(
      Array.prototype.map
        .call(
          atobFn(base64),
          (c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2)
        )
        .join("")
    );
  } catch {
    return null;
  }
}

function parseJwt(token) {
  if (!token || typeof token !== "string") return null;
  const parts = token.split(".");
  if (parts.length < 2) return null;
  const json = decodeBase64Url(parts[1]);
  try {
    return json ? JSON.parse(json) : null;
  } catch {
    return null;
  }
}

// Async thunk for login
export const login = createAsyncThunk(
  "auth/login",
  async (credentials, thunkAPI) => {
    try {
      const res = await axios.post(`${API_BASE_URL}/auth/login`, credentials, {
        headers: { "Content-Type": "application/json" },
      });

      // axios puts response data on res.data
      const data = res.data;
      return data;
    } catch (err) {
      // Prefer structured error returned by server, otherwise fallback to network/error message
      const message =
        err?.response?.data?.message || err.message || "Network error";
      return thunkAPI.rejectWithValue({ message });
    }
  }
);

// Initialize auth from localStorage on app start
export const initializeAuth = createAsyncThunk(
  "auth/initialize",
  async (_, { fulfillWithValue }) => {
    if (typeof window === "undefined") return fulfillWithValue(null);
    // Prefer structured 'auth' object, but fall back to legacy/raw 'authToken'
    const raw = localStorage.getItem("auth");
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        const { token, user, roles, permissions, exp } = parsed || {};
        const now = Date.now();
        if (!token || (exp && now > exp)) {
          localStorage.removeItem("auth");
          localStorage.removeItem("authToken");
          return fulfillWithValue(null);
        }
        if (axios?.defaults?.headers) {
          axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
        }
        return fulfillWithValue({ token, user, roles, permissions, exp });
      } catch {
        localStorage.removeItem("auth");
      }
    }

    // Fallback: raw token stored under 'authToken'
    const rawToken = localStorage.getItem("authToken");
    if (!rawToken) return fulfillWithValue(null);
    try {
      const decoded = parseJwt(rawToken);
      const roles = Array.isArray(decoded?.roles) ? decoded.roles : [];
      const permissions = Array.isArray(decoded?.permissions)
        ? decoded.permissions
        : [];
      const user = decoded?.user || {
        username: decoded?.sub || null,
        email: decoded?.email || null,
        firstName: decoded?.firstName || null,
        lastName: decoded?.lastName || null,
        userId: decoded?.userId || null,
      };
      const exp = decoded?.exp ? decoded.exp * 1000 : null;
      if (axios?.defaults?.headers) {
        axios.defaults.headers.common["Authorization"] = `Bearer ${rawToken}`;
      }
      return fulfillWithValue({
        token: rawToken,
        user,
        roles,
        permissions,
        exp,
      });
    } catch {
      // invalid token
      localStorage.removeItem("authToken");
      return fulfillWithValue(null);
    }
  }
);

// Hydrate legacy `authUser` shape from localStorage (keeps backward compatibility)
export const hydrateAuth = createAsyncThunk(
  "auth/hydrateAuth",
  async (_, thunkAPI) => {
    try {
      const stored = localStorage.getItem("authUser");
      if (stored) {
        const parsed = JSON.parse(stored);
        const { user, roles, permissions, exp, token } = parsed;

        if (!token || !exp || !permissions) {
          return thunkAPI.rejectWithValue({ message: "Invalid stored auth" });
        }

        console.log("Hydrating auth...");
        console.log("Stored authUser:", localStorage.getItem("authUser"));

        return { user, roles, permissions, exp, token };
      }
      return thunkAPI.rejectWithValue({ message: "No stored auth" });
    } catch {
      return thunkAPI.rejectWithValue({ message: "Failed to hydrate auth" });
    }
  }
);

const initialState = {
  user: null, // { username, email, firstName, lastName, userId }
  roles: [],
  permissions: [],
  token: null,
  expiresAt: null, // epoch ms
  status: "idle", // 'idle' | 'loading' | 'succeeded' | 'failed'
  error: null,
  message: null,
  isAuthenticated: false,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout(state) {
      state.user = null;
      state.roles = [];
      state.permissions = [];
      state.token = null;
      state.expiresAt = null;
      state.status = "idle";
      state.error = null;
      state.message = null;
      state.isAuthenticated = false;
      // Optional: clear localStorage tokens
      if (typeof window !== "undefined") {
        localStorage.removeItem("auth");
        // Remove legacy key if still present
        localStorage.removeItem("authUser");
        // Also remove raw token key
        localStorage.removeItem("authToken");
      }
      // Clear axios Authorization header
      if (axios && axios.defaults && axios.defaults.headers) {
        delete axios.defaults.headers.common["Authorization"];
      }
    },
    clearError(state) {
      state.error = null;
      state.message = null;
    },
  },
  extraReducers(builder) {
    builder
      .addCase(login.pending, (state) => {
        state.status = "loading";
        state.error = null;
        state.message = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        const payload = action.payload || {};
        // API may return { data: { token, user }, message, status }
        const apiData = payload.data || payload;
        const token = apiData?.token || apiData?.accessToken || null;
        const decoded = token
          ? parseJwt(token)
          : apiData.permissions || apiData.roles
          ? apiData
          : null;

        const rolesFromToken = Array.isArray(decoded?.roles)
          ? decoded.roles
          : [];
        const rolesFromApi = Array.isArray(apiData?.roles) ? apiData.roles : [];
        const roles = [
          ...new Set([
            ...rolesFromToken,
            ...rolesFromApi
              .map((r) => (typeof r === "string" ? r : r?.authority))
              .filter(Boolean),
          ]),
        ];

        const permissions = Array.isArray(decoded?.permissions)
          ? decoded.permissions
          : Array.isArray(apiData?.permissions)
          ? apiData.permissions
          : [];

        const userFromApi = apiData?.user || {};
        const userFromToken = decoded?.user || {};
        const user = {
          username:
            userFromApi?.username ||
            userFromToken?.username ||
            decoded?.sub ||
            null,
          email: userFromApi?.email || userFromToken?.email || null,
          firstName: userFromApi?.firstName ?? userFromToken?.firstName ?? null,
          lastName: userFromApi?.lastName ?? userFromToken?.lastName ?? null,
          userId: userFromApi?.userId ?? userFromToken?.userId ?? null,
        };

        const exp = decoded?.exp ? decoded.exp * 1000 : null;

        state.status = "succeeded";
        state.user = user;
        state.roles = roles;
        state.permissions = permissions;
        state.token = token;
        state.expiresAt = exp;
        state.message = payload.message || payload.status || "success";
        state.error = null;
        state.isAuthenticated = Boolean(
          token || roles.length || permissions.length
        );

        if (
          (token || roles.length || permissions.length) &&
          axios?.defaults?.headers
        ) {
          if (token)
            axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
        }

        if (typeof window !== "undefined") {
          localStorage.setItem(
            "auth",
            JSON.stringify({ token, user, roles, permissions, exp })
          );
          // Also save raw token for other code paths that expect it
          if (token) localStorage.setItem("authToken", token);
        }
      })
      .addCase(login.rejected, (state, action) => {
        state.status = "failed";
        state.error =
          (action.payload && action.payload.message) || action.error.message;
        state.message = null;
        state.isAuthenticated = false;
      })
      //hydrateAuth lifecycle
      .addCase(hydrateAuth.fulfilled, (state, action) => {
        const { user, roles, permissions, exp, token } = action.payload;
        const now = Date.now() / 1000;

        if (exp && exp < now) {
          state.status = "failed";
          state.user = null;
          state.roles = [];
          state.permissions = [];
          state.token = null;
          state.isAuthenticated = false;
          state.error = "Session expired. Please login again.";
          return;
        }

        state.user = user;
        state.roles = roles;
        state.permissions = permissions;
        state.token = token;
        state.isAuthenticated = true;
        state.status = "succeeded";
      })
      .addCase(hydrateAuth.rejected, (state) => {
        localStorage.removeItem("authUser");
        state.user = null;
        state.roles = [];
        state.permissions = [];
        state.token = null;
        state.status = "failed";
        state.isAuthenticated = false;
      })
      .addCase(initializeAuth.fulfilled, (state, action) => {
        const data = action.payload;
        if (!data) return;
        state.token = data.token;
        state.user = data.user || null;
        state.roles = data.roles || [];
        state.permissions = data.permissions || [];
        state.expiresAt = data.exp || null;
        state.isAuthenticated = true;
        if (state.status === "idle") state.status = "succeeded";
      });
  },
});

export const { logout, clearError } = authSlice.actions;

export default authSlice.reducer;

// Selectors
export const selectAuth = (state) => state.auth;
export const selectIsAuthenticated = (state) => state.auth.isAuthenticated;
export const selectCurrentUser = (state) => state.auth.user;
export const selectAuthRoles = (state) => state.auth.roles;
export const selectAuthPermissions = (state) => state.auth.permissions || [];
export const selectAuthToken = (state) => state.auth.token || null;
export const selectAuthExpiry = (state) => state.auth.expiresAt || null;
export const selectAuthStatus = (state) => state.auth.status;
export const selectAuthError = (state) => state.auth.error;
export const selectAuthMessage = (state) => state.auth.message;
export const makeSelectHasPermission = (permission) => (state) =>
  Array.isArray(state.auth.permissions) &&
  state.auth.permissions.includes(permission);
export const makeSelectHasRole = (role) => (state) =>
  Array.isArray(state.auth.roles) && state.auth.roles.includes(role);
